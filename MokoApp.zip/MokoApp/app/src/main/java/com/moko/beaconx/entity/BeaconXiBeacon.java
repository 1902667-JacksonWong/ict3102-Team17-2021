package com.moko.beaconx.entity;

import java.io.Serializable;


public class BeaconXiBeacon implements Serializable {
    public String rangingData;
    public String uuid;
    public String major;
    public String minor;
}
